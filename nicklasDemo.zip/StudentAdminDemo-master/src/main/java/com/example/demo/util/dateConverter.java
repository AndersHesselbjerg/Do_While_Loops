package com.example.demo.util;

import java.util.Date;

public class dateConverter {
    Date date;

    Date sqlDateConverter(Date date){
        java.sql.Date sqlDate = new java.sql.Date(java.util.Date);

    }

}
